package uz.megashop.onlineshopapp.domain.enums;

public enum PayType {

    CLICK,
    PAYME,
    PAYNET,
    CARD
}
