package uz.megashop.onlineshopapp.config.jwt;


import org.springframework.security.config.web.server.ServerHttpSecurity;

public class JwtProvider {

}
