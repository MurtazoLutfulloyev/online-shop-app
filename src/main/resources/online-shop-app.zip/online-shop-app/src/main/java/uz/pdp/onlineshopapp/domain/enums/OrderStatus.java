package uz.megashop.onlineshopapp.domain.enums;

public enum OrderStatus {

    PENDING,
    ACCEPTED,
    CANCELLED,
    PREPARING,
    COMPLETED
}
