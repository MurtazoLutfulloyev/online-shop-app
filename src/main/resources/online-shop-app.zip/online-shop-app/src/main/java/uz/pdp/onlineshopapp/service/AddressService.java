package uz.megashop.onlineshopapp.service;

import org.springframework.stereotype.Service;
@Service
public interface  AddressService {
}
