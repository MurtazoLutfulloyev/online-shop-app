package uz.megashop.onlineshopapp.domain.enums;

public enum CustomerType {

    MALE,
    FEMALE,
    CHILDREN
}
