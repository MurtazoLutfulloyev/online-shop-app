package uz.megashop.onlineshopapp.service.impl;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import uz.megashop.onlineshopapp.service.AddressService;

@Slf4j
@Service
public class AddressServiceImpl implements AddressService {
}
