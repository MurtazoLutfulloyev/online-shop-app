package uz.megashop.onlineshopapp.domain.enums;

public enum RolesEnum {

    SUPERADMIN,
    ADMIN,
    CUSTOMER
}
